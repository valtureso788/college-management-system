
using System;

namespace CollegeManagementSystem.Services {
    public class StudentService {
        public void RegisterStudent(string name, DateTime birthDate, int groupId) {
            // Здесь бы вызывался DatabaseManager, в полноценной реализации он передавался бы через DI
            Console.WriteLine($"Student {name} registered.");
        }
    }
}
