
using System;
using CollegeManagementSystem.Services;

namespace CollegeManagementSystem {
    class Program {
        static void Main(string[] args) {
            var studentService = new StudentService();
            Console.WriteLine("1. Add student");
            var choice = Console.ReadLine();
            if (choice == "1") {
                Console.Write("Enter name: ");
                string name = Console.ReadLine();
                Console.Write("Enter birth date (yyyy-MM-dd): ");
                DateTime birthDate = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter group id: ");
                int groupId = int.Parse(Console.ReadLine());

                studentService.RegisterStudent(name, birthDate, groupId);
            }
        }
    }
}
